package mock1.mock1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Mock1SpringApplicationTests {

    @Test
    void contextLoads() {
    }

}
