package mock1;

public class OutputValidator {
}
